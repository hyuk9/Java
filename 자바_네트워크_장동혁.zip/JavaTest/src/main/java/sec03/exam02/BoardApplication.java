package sec03.exam02;

/**
 * packageName : sec03.exam02
 * fileName : BoardApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : Board 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
//  결과 :
//
public class BoardApplication extends Board {
    public static void main(String[] args) {

        Board board = new Board();
        System.out.println(board.getTitle() + " : " + board.getContent());

        Board board2 = new Board("시험");
        System.out.println(board2.getTitle() + " : " + board2.getContent());

        Board board3 = new Board("시험", "오늘은 시험치는 날입니다.");
        System.out.println(board3.getTitle() + " : " + board3.getContent());
    }
}
