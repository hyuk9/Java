package sec03.exam02;

/**
 * packageName : sec03.exam02
 * fileName : Board
 * author : kangtaegyung
 * date : 2022/10/07
 * description : Board 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 2 : BoardApplication 클래스와 실행결과를 보고 Board 클래스를 완성하세요.
//  결과 :
//     제목 : 내용
//     시험 : 내용
//     시험 : 오늘은 시험치는 날입니다.
public class Board {
    String title;
    String content;

    public Board(){
        title = "제목";
        content = "내용";
    }

    public Board(String str1) {
        title = str1;
        content = "내용";
    }

    public Board(String str1, String str2){
        title = str1;
        content = str2;
    }

    public String getTitle() {
        return title;
    }

    public String getContent() {
        return content;
    }
}
