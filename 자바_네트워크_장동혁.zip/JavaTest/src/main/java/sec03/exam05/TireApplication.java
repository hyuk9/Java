package sec03.exam05;

/**
 * packageName : sec03.exam05
 * fileName : TireApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 5 : 아래 실행 클래스와 결과를 보고 Tire, SnowTire, WideTire 를 작성하세요.
// 결과 :
//      일반 타이어가 굴러갑니다.
//      스노우 타이어가 굴러갑니다.
//      광폭 타이어가 굴러갑니다.
public class TireApplication {
    public static void main(String[] args) {
        Tire tire = new Tire();
        SnowTire snowTire = new SnowTire();
        WideTire wideTire = new WideTire();

        tire.run(); // 일반 타이어가 굴러갑니다. 출력

        tire = snowTire; // 스노우타이어로 교체
        tire.run(); // 스노우 타이어가 굴러갑니다. 출력

        tire = wideTire;
        tire.run(); // 광폭 타이어가 굴러갑니다. 출력
    }
}
