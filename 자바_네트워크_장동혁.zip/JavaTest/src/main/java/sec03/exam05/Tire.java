package sec03.exam05;

/**
 * packageName : sec03.exam05
 * fileName : Tire
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 부모 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Tire {
    public void run(){
        System.out.println("일반 타이어가 굴러갑니다.");
    }
}
