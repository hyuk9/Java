package sec03.exam08;

/**
 * packageName : sec03.exam08
 * fileName : DaoApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 8 : DaoApplication 클래스의 main() 함수에서 dbWork() 함수를 호출할 때 OracleDao, MySqlDao,
//    ,DB2Dao 객체를 매개변수값으로 주고 호출했습니다. dbWork() 함수는 두 객체를 모두 매개변수값으로 받기 위해
//    DataAccessObject 타입의 매개변수를 가지고 있습니다. 실행 결과를 보고 DataAccessObject 인터페이스와
//    OracleDao, MySqlDao, Db2Dao 구현 클래스를 각각 작성해 보세요.
//   결과 :
//      Oracle DB에서 검색
//      Oracle DB에 삽입
//      Oracle DB를 수정
//      Oracle DB에서 삭제
//      MySql DB에서 검색
//      MySql DB에 삽입
//      MySql DB를 수정
//      MySql DB에서 삭제
//      DB2 DB에서 검색
//      DB2 DB에 삽입
//      DB2 DB를 수정
//      DB2 DB에서 삭제
public class DaoApplication {
    public static void dbWork(DataAccessObject dao) {
        dao.select(); // 검색
        dao.insert(); // 삽입
        dao.update(); // 수정
        dao.delete(); // 삭제
    }


    public static void main(String[] args) {
        dbWork(new OracleDao()); // OracleDao 함수 실행
        dbWork(new MySqlDao());  // MySqlDao 함수 실행
        dbWork(new Db2Dao()); // Db2Dao 함수 실행
    }
}
