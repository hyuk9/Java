package sec03.exam08;

/**
 * packageName : sec03.exam08
 * fileName : DataAccessObject
 * author : kangtaegyung
 * date : 2022/10/07
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public interface DataAccessObject {

    void select();
    void insert();
    void update();
    void delete();
}