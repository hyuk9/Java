package sec03.exam07;

/**
 * packageName : sec03.exam07
 * fileName : SoundableApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 7 : Soundable 인터페이스의 sound() 추상함수는 객체의 소리를 리턴합니다.
//    SoundableApplication 클래스에서 printSound() 함수는 Soundable 인터페이스 타입(자료형)의
//    매개변수를 가지고 있습니다. main() 함수에서 printSound()를 호출할 때 Cat과 Dog 객체를 주고
//    실행하면 각각 "야옹"과 "멍멍" 이 출력되도록 Cat과 Dog 클래스를 작성해 보세요.
public class SoundableApplication {

//    공유 함수
    public static void printSound(Soundable soundable) {
        System.out.println(soundable.sound());
    }

    public static void main(String[] args) {
        printSound(new Cat()); // 야옹 출력
        printSound(new Dog()); // 멍멍 출력
    }
}
