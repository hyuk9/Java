package sec03.exam07;

/**
 * packageName : sec03.exam07
 * fileName : Soundable
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 인터페이스(부모)
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public interface Soundable {
    String sound();
}
