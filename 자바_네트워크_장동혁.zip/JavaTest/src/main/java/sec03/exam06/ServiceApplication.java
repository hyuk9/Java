package sec03.exam06;

/**
 * packageName : sec03.exam06
 * fileName : ServiceApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 6: Service 부모클래스, ServiceApplication 실행클래스의 코드와 실행 결과를 보고
//    MemberService, AService, Controller 클래스를 작성하세요
//    ( 매개변수의 다형성 이용 : 전략 클래스( Controller ) )
//  결과 :
//    멤버 로그인
//    A 로그인
public class ServiceApplication {
    public static void main(String[] args) {
//        Controller 객체 출력
        Controller controller = new Controller();

        controller.setService(new MemberService());
        controller.service.login(); // 멤버 로그인 출력

        controller.setService(new AService());
        controller.service.login(); // A 로그인 출력

    }
}
