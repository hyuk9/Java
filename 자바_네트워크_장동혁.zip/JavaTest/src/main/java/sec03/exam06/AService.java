package sec03.exam06;

/**
 * packageName : sec03.exam06
 * fileName : AService
 * author : kangtaegyung
 * date : 2022/10/07
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class AService extends Service {
    @Override
    public void login() {
        System.out.println("A 로그인");
    }
}
