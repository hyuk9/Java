package sec03.exam06;

/**
 * packageName : sec03.exam06
 * fileName : Service
 * author : kangtaegyung
 * date : 2022/10/07
 * description : Service (부모 클래스)
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Service {
    public void login() {
        System.out.println("로그인");
    }
}
