package sec03.exam06;

/**
 * packageName : sec03.exam06
 * fileName : Controller
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 전략 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Controller {
    public Service service;

    public void setService(Service service) {
        this.service = service;
    }
}
