package sec03.exam06;

/**
 * packageName : sec03.exam06
 * fileName : MemberService
 * author : kangtaegyung
 * date : 2022/10/07
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class MemberService extends Service{
    @Override
    public void login() {
        System.out.println("멤버 로그인");
    }
}
