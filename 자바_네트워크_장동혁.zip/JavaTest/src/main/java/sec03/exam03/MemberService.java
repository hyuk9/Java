package sec03.exam03;

/**
 * packageName : sec03.exam03
 * fileName : MemberService
 * author : kangtaegyung
 * date : 2022/10/07
 * description : Member Service
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 3 : MemberApplication 과 결과를 보고 MemberService 를 완성하세요.
//      MemberService 클래스에 login() 함수와 logout() 함수를 선언하려고 합니다.
//      login() 함수를 호출할 때에는 매개변수값으로 id와 password를 제공하고, logout() 함수는
//      id만 매개변수값으로 제공합니다. MemberService에 login(), logout() 함수를 선언해 보세요.
//      1) login() 함수 : 매개변수값 id 가 hong 매개변수값 password 가 12345 일 경우에만 true 로 리턴하고,
//         그 이외의 값일 경우에는 false 를 리턴하도록 하세요.
//      2) logout() 함수 : "로그아웃 되었습니다." 가 출력되도록 하세요.
//   결과 :
//      로그인 되었습니다.
//      로그아웃 되었습니다.
public class MemberService {
    public boolean login(String str1, String str2){
     if (str1.equals("hong") && str2.equals("12345")){
         return true;
     }else {
         return false;
     }
    }

    public String logout(String str1){
        return "로그아웃 되었습니다.";
    }
}
