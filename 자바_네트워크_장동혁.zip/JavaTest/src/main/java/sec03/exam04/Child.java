package sec03.exam04;

/**
 * packageName : sec03.exam04
 * fileName : Child
 * author : kangtaegyung
 * date : 2022/10/07
 * description :
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Child extends Parent {

}
