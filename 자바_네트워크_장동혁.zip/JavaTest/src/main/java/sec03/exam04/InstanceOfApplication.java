package sec03.exam04;

/**
 * packageName : sec03.exam04
 * fileName : InstanceOfApplication
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 실행 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 4 : 결과를 보고 아래 method1() 함수를 완성하세요.
//     아래 예제는 다형성을 이용하고 있습니다. method1() 함수에서 Child로 강제 형변환이 가능하면
//      Child로 객체 자료형변환(원복) 과 동시에 "Child로 변환 성공" 이라고 출력하고,
//      아니면 "Child로 변환되지 않음" 출력하세요.
// 결과 :
//    Child로 변환 성공
public class InstanceOfApplication {

    public static void method1(Parent parent) {
//        로직을 작성하세요.
        if (parent instanceof Child){
            Child child = (Child) parent;
            System.out.println("Child로 변환 성공");
        }else {
            System.out.println("Child로 변환되지 않음");
        }
    }

    public static void main(String[] args) {
        Parent parentA = new Child();
        method1(parentA);
    }
}
