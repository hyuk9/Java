package sec03.exam01;

/**
 * packageName : sec03.exam01
 * fileName : Member
 * author : kangtaegyung
 * date : 2022/10/07
 * description : Member 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
// 문제 1 : 현실 세계의 회원을 Member 클래스로 모델링하려고 합니다. 회원의 데이터로는 이름, 아이디, 패스워드, 나이가 있습니다.
//    이들 데이터를 가지는 Member 클래스를 선언해 보세요.
//    속성의 접근제한자는 모두 외부에서 직접 접근 못하게 막고, 속성에 해당하는 Getter/Setter 를 각각 만들어서
//    외부에서(다른 객체에서) 함수 호출이 가능하게 Member 클래스를 코딩하세요.
//    데이터 이름 | 필드 이름 | 타입
//    이름      | name    | 문자열
//   아이디      | id      | 문자열
//   패스워드    | password | 문자열
//    나이      | age      | 정수
public class Member {
    private String name;
    private String id;
    private String pw;
    private int age;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPw() {
        return pw;
    }

    public void setPw(String pw) {
        this.pw = pw;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }
}
