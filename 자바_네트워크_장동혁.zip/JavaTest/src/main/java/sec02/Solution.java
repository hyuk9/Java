package sec02;

import sec03.exam04.Parent;

import java.util.Scanner;

/**
 * packageName : exam02
 * fileName : Solution
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 해답을 위한 클래스
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Solution {
    public static void examSol01(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("1. 이름 : ");
        String name = scanner.next();
        System.out.print("2. 주민번호 앞 6자리 : ");
        int ssn = scanner.nextInt();
        System.out.print("3. 전화번호 : ");
        String phoneNum = scanner.next();
        System.out.println("[ 1번 문제 답 ]\n"+name+"\n"+ssn+"\n"+phoneNum);
    }

    public static void examSol02(){
        System.out.println("[ 2번 문제 답 ]\n이름 : 감자바\n나이 : 25\n전화 : 010-123-4567");

    }

    public static void examSol03(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("첫 번째 수 : ");
        double num1 = scanner.nextDouble();
        System.out.print("두 번째 수 : ");
        double num2 = scanner.nextDouble();

        if (num2 == 0.0){
            System.out.println("[ 3번 문제 답 ]\n결과 : 무한대");
        } else {
            double result = num1 / num2;
            System.out.println("[ 3번 문제 답 ]\n결과 : " + result);
        }
    }

    public static void examSol04(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("아이디 : ");
        String id = scanner.nextLine();
        System.out.print("패스워드 : ");
        int pw = scanner.nextInt();

        if (id.equals("java") && pw == 12345){
            System.out.println("[ 4번 문제 답 ]\n로그인 성공");
        } else {
            System.out.println("[ 4번 문제 답 ]\n로그인 실패");
        }
    }

    public static void examSol05(){
        int result = 0;
        for (int i = 1; i <=100 ; i++) {
            if (i%3==0){
                result += i;
            }
        }
        System.out.println("[ 5번 문제 답 ]\n"+result);
    }

    public static void examSol06(){
        System.out.println("[ 6번 문제 답 ]");
        for (int i = 0; i < 4; i++) {
            for (int j = 0; j <= i; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }

    public static void examSol07(){
        int[] arr = {1, 5, 3, 8, 2};
        int max = 0;
        for (int i = 0; i < arr.length; i++) {
            if (arr[i]>max){
                max = arr[i];
            }
        }
        System.out.println("[ 7번 문제 답 ]\nmax : "+max);
    }

    public static void examSol08(){
        Scanner scanner = new Scanner(System.in);
        System.out.print("괄호 : ");
        String[] brackets = scanner.nextLine().split("");

        int count1 = 0;
        int count2 = 0;

        for (int i = 0; i < brackets.length; i++) {
            if (brackets[i].equals("(")) count1++;
            if (brackets[i].equals(")")) count2++;
        }
        System.out.println("[ 8번 문제 답 ]\n"+count1 + " " +count2);
    }

    public static void examSol09() {
        Scanner scanner = new Scanner(System.in);
        System.out.print("평문 : ");
        String str = scanner.nextLine();

        String result1 = "";
        String result2 = "";

        for (int i = 0; i < str.length(); i++) {
            result1 += (char)(str.charAt(i)+2);
            result2 += (char)((str.charAt(i)*7)%80+48);
        }

        System.out.println("[ 9번 문제 답 ]\n"+result1+"\n"+result2);

    }

    public static void examSol10(){
        int count = 0;
        Scanner scanner = new Scanner(System.in);
        System.out.print("문장 : ");
        String[] str = scanner.nextLine().split(" ");

        for (int i = 0; i < str.length; i++) {
            if (str[i].contains("love")){
                count++;
            }
        }
        
        System.out.println("[ 10번 문제 답 ]\n"+count);
    }
}














