package sec01;

/**
 * packageName : exam01
 * fileName : theory
 * author : kangtaegyung
 * date : 2022/10/07
 * description : 자바 이론 평가
 * 요약 :
 * <p>
 * ===========================================================
 * DATE            AUTHOR             NOTE
 * -----------------------------------------------------------
 * 2022/10/07         kangtaegyung          최초 생성
 */
public class Theory {
    public static void main(String[] args) {
//        아래는 자바에 관련한 기초적인 이론 문제들입니다. () 안의 변수에(solution) 답을 기입해서 출력하세요.
//        1) 자바의 실행 환경
        String solution = "JVM";
        System.out.println("(" + solution + ") : 바이트 코드 파일을 운영체제를 위한 완전한 기계어로 번역하고 실행하는 역할을 합니다. java 명령어에 의해 구동됩니다.");

//        2) 하나의 값을 저장하는 곳
        solution = "변수";
        System.out.println("(" + solution + ") : 값을 저장할 수 있는 메모리 번지에 붙인 이름입니다. 한가지 값만 저장할 수 있습니다.");

//        3) 기본 자료형(타입)
        solution = "int";
        System.out.println("정수형은 byte, short, (" + solution + "), long 이 있으며 실수형은 float, double, 그외 char, boolean 타입이 있습니다.");

//        4) 비교
        solution = ".equals()";
        System.out.println("== 는 기본 자료형에서 값을 비교하고 String 문자열에서는 (" + solution + ") 을/를 비교합니다. == 이 true 가 나오면 같은 객체를 참조하고, false 이면 다른 객체를 참조한다는 뜻");

//        5) 여러 자료를 저장하는 곳
        solution = "배열";
        System.out.println("(" + solution + ") : 같은 타입의 데이터를 연속된 공간에 나열하고, 각 데이터에 인덱스를 부여해 놓은 자료구조입니다. ");

//        6) 객체 지향 프로그래밍
        solution = "클래스";
        System.out.println("(" + solution + ") : 객체를 만들기 위한 또는 정의하기 위한 구조/설계도입니다. 내부에 속성, 생성자, 함수가 정의됩니다. ");

        solution = "new";
        System.out.println("(" + solution + ") : 객체 생성 연산자이며, 생성자를 호출하고 객체 생성 번지를 리턴합니다. ");

        solution = "멤버속성";
        System.out.println("(" + solution + ") : 객체의 3요소 중 객체의 특징을 나타내며, 생성자, 함수(메소드)와 더불어 선언됩니다. ");

        solution = "오버로딩";
        System.out.println("(" + solution + ") : 함수의 이름은 같으나 매개변수를 달리하는 생성자를 여러 개 선언하는 것을 말합니다. 객체지향코딩 언어에서만 사용가능합니다. ");

        solution = "void";
        System.out.println("리턴값이 없는 함수(메소드)는 리턴 타입으로 함수명 앞에 (" +  solution + ") 을/를 기술해야 합니다.");

//        7) 객체 지향 언어의 기법들(기능들)
        solution = "상속";
        System.out.println("(" + solution + ") : 부모 클래스의 속성(필드)과 함수(메소드)를 자식 클래스에서 사용할 수 있도록 합니다. ");

        solution = "오버라이딩";
        System.out.println("(" + solution + ") : 부모 클래스의 메소드를 자식 클래스에서 다시 정의하는 것을 말합니다. ");

        solution = "Getter, Setter";
        System.out.println("(" + solution + ") : 속성(필드)은 외부에서 접근할 수 없도록 막고 함수(메소드)는 공개해서 외부에서 함수(메소드)를 통해 속성에 접근하도록 유도하는 함수 2가지 작성하세요 ");

        solution = "추상함수";
        System.out.println("(" + solution + ") : 추상 클래스에서만 선언할 수 있고, 함수의 선언부만(실행블록{} 없음) 있는 함수(메소드)를 말합니다. 자식 클래스에서 반드시 재정의되어 실행해야 합니다.");

        solution = "인터페이스";
        System.out.println("(" + solution + ") : 모든 속성은 상수가 되고, 모든 함수는 선언부만 존재하는 함수만 있는 객체의 구조(설계도)입니다. 구현(자식)클래스에서 무조건 함수를 재정의해서 사용해야 합니다.");

        solution = "다형성";
        System.out.println("(" + solution + ") : 사용방법(함수 호출)은 같으나 속성 또는 매개변수로 전달되는 자식객체에 따라 결과가 달라지는 현상을 말합니다. 부모 - 자식 관계에서만 사용가능합니다.");

//        8) 에러
        solution = "예외처리";
        System.out.println("(" + solution + ") : 프로그램에서 에러가 발생했을 경우 프로그램의 갑잡스러운 종료를 막고, 정상 실행을 유지할 수 있도록 처리하는 것을 말합니다. try-catch-finally 구문을 이용합니다. ");

//        9) 자바의 기본 자료구조
        solution = "List";
        System.out.println("(" + solution + ") : 배열과 비슷하게 객체를 인덱스로 관리합니다.(순서가 있음) 배열과 차이점은 저장용량이 자동 증가됩니다. 중복저장이 가능하고 인터페이스입니다. ");

        solution = "MAP";
        System.out.println("(" + solution + ") : 키와 값으로 구성된 구조를 가지고 있습니다. 인터페이스이며 키는 유일해야하고, 값은 중복저장이 가능합니다. ");

        solution = "SET";
        System.out.println("(" + solution + ") : 저장 순서가 없습니다. 인터페이스이며 수학의 집합과 비슷한 자료구조입니다. ");

//        10) 자바의 그외 자료구조
        solution = "스택";
        System.out.println("(" + solution + ") : LIFO(Last In First Out), 후입선출을 구현한 클래스입니다. 제일 마지막 자료가 먼저 나옵니다. ");

        solution = "큐";
        System.out.println("(" + solution + ") : FIFO(First In First Out), 선입선출에 필요한 함수를 정의한 인터페이스입니다. 구현 클래스는 LinkedList 가 있습니다. ");

    }
}
















